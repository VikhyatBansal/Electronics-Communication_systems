Eg = 0:10:200
N = (Eg*15)/2
plot(N,Eg)
xlabel('Speed of Rotation')
ylabel('EMF Generated')
title('relationship b/w EMF Generated and Speed of rotation')