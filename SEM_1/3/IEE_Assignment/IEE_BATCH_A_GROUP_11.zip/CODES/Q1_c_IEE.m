N = 0:10:1500;
phi = 75./N;
plot(N,phi)
xlabel('Speed Of Rotation')
ylabel('Magnetic Flux Intensity')
title('Relationship b/w Magnetic Flux Intensity and Speed of Rotation')