Resistance = [60 -30 0;-30 180 -60;0 -60 300]
Voltage = [100;0;0]
Current = inv(Resistance)*Voltage