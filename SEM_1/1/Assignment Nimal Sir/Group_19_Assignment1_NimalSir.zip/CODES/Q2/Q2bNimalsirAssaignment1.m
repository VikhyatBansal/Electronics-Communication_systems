Resistance = [3 -2 -1;4 -7 1;6 -9 3]
Current = [12;0;0]
Voltage = inv(Resistance)*Current